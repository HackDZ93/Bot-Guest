Pourquoi dans Computer MOR P2 quand vous lancer "GUEST" Ne marche pas
Bon vous avez installez GUEST et vous mettez les fichier DANS "Computer MOR P2" et 
apres la vous pouvez lancez l'application 